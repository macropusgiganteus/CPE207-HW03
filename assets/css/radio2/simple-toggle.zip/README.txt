A Pen created at CodePen.io. You can find this one at http://codepen.io/magnificode/pen/ojYJJP.

 Simple toggle button.